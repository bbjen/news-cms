<?php
class Slide{
    // where are the images stored?
    var $imgfolder      = "/demos/slide_img/";
    var $dbconnection   = false;    
    // =============================================
    // Method      : constructor    
    // Paramaters  : none
    // Return Value: none 
    // Purpose     : instantiate the database connection
    // Author      : Kevin Dubois
    // =============================================    
    public function __construct()
    {
        // connect to database YOU WILL NEED TO INSERT YOUR DATABASE INFO HERE
        $this->dbconnection = mysql_connect('localhost', 'xxxx', 'xxxx') or die("Database Connection Failure");
        mysql_select_db("xxxx", $this->dbconnection) or die("Database not found");
       
    }
    
    // =============================================
    // Method      : destruct    
    // Paramaters  : none
    // Return Value: none 
    // Purpose     : close the database connection
    // Author      : Kevin Dubois
    // ============================================= 
    public function __destruct(){
        // close db connection
        mysql_close($this->dbconnection);
    }
    
    // =============================================
    // Method      :  get_slides()
    // Paramaters  :  none
    // Return Value:  array slides: all database records
    // Purpose     :  get all slides 
    // Author      :  Kevin Dubois     
    // =============================================       
    public function get_slides()
    {
        // get slides from db query
        $query = "  SELECT id, filename, title, link 
                    FROM slide_items 
                    ORDER BY id ASC";
        // send query to db
        $result = mysql_query($query);
        // define $slides
        $slides = array();
        // loop over the records and populate the slides array
        while($row = mysql_fetch_assoc($result)){
             $slides[] = $row;
        }

        return $slides;
     
    }
    
 
    public function show_slides(){
      // get the slides from db
      $files = $this->get_slides();
      // define $file_links
      $file_links = '';
      // loop over db records and create the image html code
      foreach($files as $file){
        $file_links .= <<<EOD
            <a href="{$file['link']}" id="{$file['filename']}" title="{$file['title']}">
                <img class="slideimg" alt="{$file['title']}"  src="..{$this->imgfolder}{$file['filename']}" />
            </a>
EOD;
        }
      
        return $file_links;
    }
}

// call the slide class
$slide = new Slide();

// now print the html
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-language" content="en">
<meta name="author" content="Kevin Dubois - kevin.dubois.com">
<meta name="description" content="Database Driven Slide Show Demo">
<meta name="keywords" content="">
<meta name="creation-date" content="07/29/2009">
<meta name="revisit-after" content="15 days">
<title>KevinDubois.com Database Driven Ajax jQuery Slide Show Demo</title>

<!-- Call jquery files -->
<script src="../js/jquery.js" type="text/javascript"></script> 
<script src="../js/jquery.cycle.js" type="text/javascript"></script> 
<script src="../js/jquery.easing.js" type="text/javascript"></script> 


<script type="text/javascript">
$(document).ready(function(){ 
    // make the background of the nav bar transparent 
    $("#slide-background").fadeTo(0,0.65);
    
    // instantiate the slideshow
    $('#slideshow').show();
    // define the slideshow parameters (see http://malsup.com/jquery/cycle/ for more info)
    $('#slideshow').cycle({ 
        fx:         'scrollLeft', 
        timeout:     5000, 
        pager:      '#slidenav', 
        // callback fn that creates the links for navigation 
        pagerAnchorBuilder: function(idx, slide) { 
            return '<a href="#" style="font-size:9px">'+slide.title+'</a>'; 
        }, 
        pagerEvent: 'mouseover', 
        fastOnEvent: true,
        fit:         1,
        pause: 1,
        pauseOnPagerHover: 1 
    });

    // code for the pause button
    $("#pbtn").click(function () { 
      var pbtn = $("#pbtn").html();
      if(pbtn.toLowerCase() == '<a>||</a>'){
        $("#slideshow").cycle('pause');
        $("#pbtn").html('<a>&gt;</a>');
      } else{
        $("#slideshow").cycle('resume');
        $("#pbtn").html('<a>||</a>');
      }
    });
     
    // slide down the navigation links 
    $('#slide-text').slideDown();
});



</script>

<style type="text/css">
    body{font-size:16px}
    #slidenav { display:inline; line-height:20px }   
    #slidenav a { margin: 0.5em; padding: 0.5em 1em; text-decoration: none;color:#FFF  }
    #slidenav a:hover{color:#FFF}
    #pbtn a { margin: 0.5em; padding: 0.5em 1em;  text-decoration: none;  }
    #slidenav a.activeSlide { background: #F00; color: #FFF }
    #slidenav a:focus { outline: none; }
    #pbtn a:focus { outline: none; }
    .slideimg{width:50em; border:0}
    .pics{display:none}
    #pbtn{cursor: pointer; margin: 1em; display:inline; font-size:0.8em}
    
    #slidenavmenu{position:relative;z-index:100; zoom:1}  

    #slide-background{
        position:absolute; 
        top:21px; 
        background-color:#555; 
        width:50em; 
        left:0em;
        font-size:1em;
        line-height:20px;
    }
    #slide-text{
        position:absolute; 
        width:50em; 
        left:0px;
        text-align:center;
        color:white; 
        top:20px; 
        padding-left:0.2em;
        display:none;
        font-weight:bold;
        font-family: verdana, sans-serif;
        font-size:1em;
    }
    
</style>
</head>
<body>

<div id="slidenavmenu" >
    <div id="slide-background">&nbsp;</div>
    <div id="slide-text">
        <div id="slidenav"></div>
        <div id="pbtn" ><a>||</a></div>
    </div>
</div>  
        
<div id="slideshow" class="pics">
     <?=$slide->show_slides()?>
</div> 


</body>
</html>
